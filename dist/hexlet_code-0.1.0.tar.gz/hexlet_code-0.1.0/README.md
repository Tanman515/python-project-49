### Hexlet tests and linter status:
[![Actions Status](https://github.com/Tanman515/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Tanman515/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/7a94cf443e030b04b641/maintainability)](https://codeclimate.com/github/Tanman515/python-project-49/maintainability)

Example of brain-even game : https://asciinema.org/a/VfHSU2U0JhS4xoKWKuPbieFK1

Example of brain-calc game : https://asciinema.org/a/kbBS3bUrSTGjTNIVG6B4zKnpK
